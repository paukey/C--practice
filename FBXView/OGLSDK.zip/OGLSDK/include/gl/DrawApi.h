#ifndef DRAWAPI_H
#define DRAWAPI_H
#include <stdio.h>
#include <Windows.h>
#include <glew.h>
#include <gl.h>
#include <glu.h>
#include <glut.h>

void display();
void Init(int argc, char **argv);
void IdleFunc();
void reshape(int w, int h);

#endif