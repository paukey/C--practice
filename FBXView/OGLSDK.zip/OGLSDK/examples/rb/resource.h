//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by rb.rc
//
#define IDD_DIALOG1                     101
#define IDR_MENU1                       104
#define IDD_STATS_DIALOG                107
#define IDC_DEPTHTEST                   1000
#define IDC_DITHER                      1000
#define IDC_DEPTHWRITES                 1001
#define IDC_DEPTHTESTENABLED            1002
#define IDC_FRONTBUFFER                 1003
#define IDC_TRIANGLESIZE                1004
#define IDC_COMBO2                      1005
#define IDC_DEPTHFUNC                   1005
#define IDC_ITERATIONS                  1005
#define IDC_DEPTHSIZE                   1006
#define IDC_SHADEMODEL                  1007
#define IDC_CLEARDEPTH                  1008
#define IDC_SHADEMODEL2                 1010
#define IDC_DEPTHFUNC3                  1011
#define IDC_OEMINFO                     1018
#define IDC_STATS                       1019
#define IDM_GL_FLAT                     40005
#define IDM_GL_SMOOTH                   40007
#define IDM_DITHER                      40008
#define IDM_DEPTHBUFFER_ENABLE          40009
#define IDM_GL_LESS                     40011
#define IDM_GL_LEQUAL                   40012
#define IDM_GL_EQUAL                    40013
#define IDM_GL_GEQUAL                   40014
#define IDM_GL_GREATER                  40015
#define IDM_GL_ALWAYS                   40016
#define IDM_GL_NEVER                    40017
#define IDM_GL_NOTEQUAL                 40018
#define IDM_DEPTHMASK                   40019
#define IDM_DEPTHSIZE_16                40021
#define IDM_DEPTHSIZE_32                40022
#define IDM_TEXTURE_WIDTH_1             40023
#define IDM_TEXTURE_WIDTH_2             40024
#define IDM_TEXTURE_WIDTH_4             40025
#define IDM_TEXTURE_WIDTH_8             40026
#define IDM_TEXTURE_WIDTH_16            40027
#define IDM_TEXTURE_WIDTH_32            40028
#define IDM_TEXTURE_WIDTH_64            40029
#define IDM_TEXTURE_WIDTH_128           40030
#define IDM_TEXTURE_WIDTH_256           40031
#define IDM_TEXTURE_HEIGHT_1            40032
#define IDM_TEXTURE_HEIGHT_2            40033
#define IDM_TEXTURE_HEIGHT_4            40034
#define IDM_TEXTURE_HEIGHT_8            40035
#define IDM_TEXTURE_HEIGHT_16           40036
#define IDM_TEXTURE_HEIGHT_32           40037
#define IDM_TEXTURE_HEIGHT_64           40038
#define IDM_TEXTURE_HEIGHT_128          40039
#define IDM_TEXTURE_HEIGHT_256          40040
#define IDM_TEXTURE_ENABLE              40045
#define IDM_TEXTURE_DECAL               40046
#define IDM_TEXTURE_MODULATE            40047
#define IDM_TEXTURE_REPLACE             40048
#define IDM_TEXTURE_0                   40049
#define IDM_TEXTURE_90                  40050
#define IDM_TEXTURE_180                 40051
#define IDM_TEXTURE_270                 40052
#define IDM_TEXTURE_ADD                 40053
#define IDM_DEPTHBUFFER_CLEAR0          40054
#define IDM_DEPTHBUFFER_CLEAR1          40055
#define IDM_TRIANGLE_HAT                40056
#define IDM_TRIANGLE_KNEE               40057
#define IDM_DRAW_FRONT                  40060
#define IDM_DRAW_BACK                   40061
#define IDM_FOG_ENABLE                  40063
#define IDM_FOG_LINEAR                  40064
#define IDM_FOG_EXP                     40065
#define IDM_FOG_EXP2                    40066
#define IDM_FOG_CHEAP                   40067
#define IDM_TEXTURE_PERSPECTIVE_CORRECT 40068
#define IDM_SIZE_10                     40070
#define IDM_SIZE_25                     40071
#define IDM_SIZE_50                     40072
#define IDM_SIZE_100                    40073
#define IDM_SIZE_1000                   40074
#define IDM_SIZE_10000                  40075
#define IDM_TEXTURE_WIDTH_512           40076
#define IDM_TEXTURE_HEIGHT_512          40077
#define IDM_TRIANGLES                   40078
#define IDM_TRIANGLE_STRIP              40079
#define IDM_CLAMP_S                     40080
#define IDM_CLAMP_T                     40081
#define IDM_ZOOM_1x1                    40082
#define IDM_ZOOM_1x2                    40083
#define IDM_ZOOM_1x4                    40084
#define IDM_ZOOM_1x8                    40085
#define IDM_CLEAR                       40086
#define IDM_TEXTURE_NEAREST             40087
#define IDM_TEXTURE_LINEAR              40088
#define IDM_COLORMODE_RGB               40089
#define IDM_COLORMODE_INDEX             40090
#define IDM_DRAW_ELEMENTS               40091
#define IDM_SIZE_3                      40092

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        109
#define _APS_NEXT_COMMAND_VALUE         40093
#define _APS_NEXT_CONTROL_VALUE         1020
#define _APS_NEXT_SYMED_VALUE           103
#endif
#endif
