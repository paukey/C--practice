#pragma once
#include "BaseWnd.h"
#include "string.h"
#include "VertLink.h"

class CTipWnd :	public CBaseWnd
{
protected:
	char m_TipStr[40];

public:
	CTipWnd(void);
	~CTipWnd(void);
	void SetText(const char *str);
	void OwnerDraw( CVertLink *pLink, float &deep);
};
