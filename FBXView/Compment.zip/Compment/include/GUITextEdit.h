#ifndef CGUITEXTEDIT_H
#define CGUITEXTEDIT_H

#include "BaseWnd.h"

class CGUITextEdit : public CBaseWnd
{
protected:
	bool	m_EnableEdit;		//�Ƿ���ʾ���
public:
	CGUITextEdit(void);
	~CGUITextEdit(void);
	CBaseWnd *	DynamicGetPointer();
	void		DrawOwnerFrame(CVertLink *pLink);
};

#endif
