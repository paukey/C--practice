//
//  Vector2.h


#ifndef __GLK_VECTOR_2_H
#define __GLK_VECTOR_2_H


#include <math.h>

class CVector2
{
public:
	union
	{
		struct { float x, y; };
		struct { float s, t; };
		float v[2];
	};
public:
	CVector2();
	CVector2(float x, float y);
	CVector2(float values[2]);
	CVector2 Negate();

	CVector2 operator+(const CVector2 &value);
	CVector2 operator-(const CVector2 &value);	
	
	CVector2 operator*(const CVector2 &value);
	CVector2  operator/ (const CVector2 &value);

	CVector2 operator+(float value);
	CVector2 operator-(float value);
	CVector2 operator*(float value);
	CVector2 operator/(float value);
	CVector2 Lerp(CVector2 &Target, float t);		//��Target���ƶ�t����
	
	CVector2 &operator = (const CVector2 &v);

	CVector2 Normalize();
	float	 Length();
	float    Distance(const CVector2 &vectorEnd);

	
	
	bool operator==(const CVector2 &value);
	bool operator==(const float &value);

	bool operator>(const CVector2 &value);
	bool operator>(const float &value);
	bool operator>=(const CVector2 &value);
	bool operator>=(const float &value);
	float DotProduct(const CVector2 &value);		//����

	CVector2 Vec2Project(CVector2 vecToProj, CVector2 projVector);

	CVector2 MaximumVec2(const CVector2 &value);		//ȡ��������������������
	CVector2 MinimumVec2(const CVector2 &value);		//ȡ��������������С������		

};

#endif /* __GLK_VECTOR_2_H */

