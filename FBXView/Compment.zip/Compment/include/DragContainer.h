#ifndef DRAGCONTAINER_H
#define DRAGCONTAINER_H

#include "BaseWnd.h"


class CGUIImage;
class CDragContainer:public CBaseWnd
{
protected:
	CGUIImage *m_DragImg;
public:
	CDragContainer(void);
	~CDragContainer(void);
	virtual CBaseWnd * DynamicGetPointer();
	virtual void		OnMouseIn();
	virtual void		OnMouseOut();
	int SetAction(ActionMsg msg, MyUIPoint point);
};

#endif
