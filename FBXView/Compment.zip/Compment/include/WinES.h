#ifndef CWINES_H
#define CWINES_H

class CWinES
{
public:
	CWinES(void);
	~CWinES(void);
};

#endif
