#ifndef CIMGLISTMANAGER_H
#define CIMGLISTMANAGER_H
#include "ImgList.h"

class CImgListManager
{
protected:
	CImgList		*	m_ImgListArray;			//�������õ������е�IMGLIST
	int					m_ImgListArraySize;
	int					m_CurImgListCount;

public:
	CImgListManager(void);
	~CImgListManager(void);
	void Init(int size = 100);
	void FreeImgList();
	CImgList * GetImgList(char *file, int v[],int &index);
	CImgList * Find(GLuint tID);
	CImgList * Find(char *name);
	CImgList * CreateImgList(GLuint TexID,int W, int H);
	CImgList * CreateImgList(GLuint TexID, int W, int H, int w, int h);
};

#endif
