//
//  Matrix3.h
//

#ifndef __GLK_MATRIX_3_H
#define __GLK_MATRIX_3_H

#include <stddef.h>
#include <math.h>


#include "EsKitTypes.h"
#include "Vector3.h"
#include "Quaternion.h"



class CMatrix3
{
public:
	union
	{
		struct
		{
			float m00, m01, m02;
			float m10, m11, m12;
			float m20, m21, m22;
		};
		float m[9];
		float M[3][3];
	};
	CMatrix3();
	CMatrix3(float values[9]);
	CMatrix3(float v00, float v01, float v02, float v10, float v11, float v12, float v20, float v21, float v22);

	CMatrix3(CVector3 row0, CVector3 row1, CVector3 row2,int row_col = 0);			//row_col = 0 ��ÿ��������X��ʼ����һ�У�Y��ʼ����2�� Z��ʼ��������
																					//row_col =1 �õ�һ��������ʼ����һ��...(�����Ϊ�����OPENGL)
	CMatrix3(const CQuaternion &quaternion);
	CMatrix2 GetMatrix2();
	CVector3 GetRow(int row);
	CVector3 GetColumn(int column);
	void SetRow(int row, CVector3 vector);
	void SetColumn(int column, CVector3 vector);
	//��ת�ȶ�������������ǰ�������ݣ����ǲ���һ���¶��󷵻�
	void RotateX(float radians);
	void RotateY(float radians);
	void RotateZ(float radians);

	CMatrix3 Multiply(const CMatrix3 &mat3);

	CMatrix3 MakeXRotation(float radians);
	CMatrix3 MakeYRotation(float radians);
	CMatrix3 MakeZRotation(float radians);
	
	void	 SetIdentity();
	CMatrix3 Transpose();			//ת��
	


	CMatrix3 operator+(const CMatrix3 &matrixRight);
	CMatrix3 operator-(const CMatrix3 &matrixRight);
	CMatrix3 operator*(const CMatrix3 &matrixRight);
	CMatrix3 operator/(const CMatrix3 &matrixRight);
	

	CMatrix3 MakeScale(float sx, float sy, float sz);
	void Scale(float sx, float sy, float sz);
	void ScaleWithVector3(CVector3 scaleVector);
	void ScaleWithVector4(CVector4 scaleVector);

	CVector3 operator*(const CVector3 vectorRight);
	void MultiplyVector3Array(CVector3 *vectors, int vectorCount);
	CMatrix3 MakeRotation(float radians, float x, float y, float z);
	void Rotate(float radians, float x, float y, float z);
	void RotateWithVector3(float radians, CVector3 axisVector);
	void RotateWithVector4(float radians, CVector4 axisVector);
	void MakeWithArrayAndTranspose(float values[9]);
	void MakeAndTranspose(float m00, float m01, float m02, float m10, float m11, float m12, float m20, float m21, float m22);

};





#ifdef __cplusplus
extern "C" {
#endif
    



//Matrix3 Matrix3Invert(Matrix3 matrix, bool *isInvertible);
//Matrix3 Matrix3InvertAndTranspose(Matrix3 matrix, bool *isInvertible);


    
#ifdef __cplusplus
}
#endif

#endif /* __GLK_MATRIX_3_H */
