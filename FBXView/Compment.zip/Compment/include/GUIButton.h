#ifndef CGUIBUTTON_H
#define CGUIBUTTON_H
#include "ImgList.h"
#include "BaseWnd.h" 

class CGUIButton:public CBaseWnd
{
protected:


	int m_Width;
	int m_Height;

	float m_fWndWidth;
	float m_fWndHeight;
	float x1;
	float y1;
	float x2;
	float y2;
	GLuint m_TexID;

	bool	m_MousePrompt;			//�Ƿ���ʾ��긲��,Ĭ�ϲ���ʾ
	bool	m_Prompt;				//�Ƿ����
	
	VertexStruct	m_VArray[6];	//��������
	TexStruct		m_TArray[6];
	
public:
	void UpdateQuadData();
	void SetText(const char *str);
	CGUIButton(void);
	~CGUIButton(void);
	int SetAction(ActionMsg msg, MyUIPoint point);
	void DrawOwnerFrame(CVertLink *pLink);
	void SetTexture(GLuint id);
	void SetPrompt();
	virtual CBaseWnd * DynamicGetPointer();
};

#endif
