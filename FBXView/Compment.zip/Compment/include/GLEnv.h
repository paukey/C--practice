#ifndef _CGLENV_H_
#define _CGLENV_H_
#include "Configure.h"
#ifndef OPENGLES
#include <Windows.h>
#else
typedef int HWND;
#endif


class CGLEnv
{
protected:
	bool InitGLES(int w, int h);


	void SetViewPort(int x, int y, int w, int h);
	bool CreateViewGLContext(HDC hDC);
	bool SetWindowPixelFormat(HDC hDC);
	int					m_PixelFormat;
	int					m_ViewWidth;
	int					m_ViewHeight;
public:
	HDC					m_hDC;
	HGLRC				m_RC;
	CGLEnv(void);
	~CGLEnv(void);
	bool InitGL(int w = 256, int h = 256, HWND hwnd = 0);
};

#endif
