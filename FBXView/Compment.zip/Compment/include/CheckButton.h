#ifndef UICHECKBUTTON
#define UICHECKBUTTON
#include "BaseWnd.h"

class CUICheckButton :	public CBaseWnd
{
protected:
	int   m_Align;		//���뷽ʽ1 2 3 �� �� ��  Ĭ�Ͼ���
	int	  m_CheckState;
	ImgBaseData *m_ImgData;
public:
	CUICheckButton(void);
	~CUICheckButton(void);
	void SetAlign(int align);
	void DrawOwnerFrame(CVertLink *pLink);
	int GetCheck();
	void SetCheck(int check);
	int SetAction(ActionMsg msg, MyUIPoint point);
	CBaseWnd * DynamicGetPointer();
	virtual bool Create(int x , int y , int w , int h , int ID, CBaseWnd * parent);
};

#endif //UICHECKBUTTON
