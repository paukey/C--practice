#ifndef CETXTOTEX_INCLUDE_H
#define CETXTOTEX_INCLUDE_H

#include "Configure.h"
#include <stdio.h>
#include <string.h>

class CEtxToTex
{
protected:
	bool		IsETC1Supported();
	void		LoadData(void * data, GLuint TexID, long pos);
	int			m_nWidth;
	int			m_nHeight;
	void		CreateTex(GLuint id,unsigned char * buf, int width, int height,int size, int level);
	void		CreateTex_UnComp(GLuint id,unsigned char * buf, int width, int height, int level);
public:
	CEtxToTex(void);
	~CEtxToTex(void);
	void		GetImgArea(int &w, int &h);
	void		LoadEtx(const char * filename, GLuint TexID);
	void		LoadEtxBuf(void * data, GLuint TexID);
	void		SetTexType(GLenum type,int face = 0);
};
#endif
