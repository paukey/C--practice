#ifndef CONFIGURE_H
#define CONFIGURE_H

#undef OPENGLES
//#define OPENGLES

#ifdef OPENGLES
	#include "GLES2/gl2.h"
	#include "EGL/egl.h"
	#include "GLES2/gl2ext.h"
#else
	#ifdef WIN32
		#include <windows.h>
	#endif
	#include "glew.h"
	#include "gl.h"
	#include "glu.h"
#endif

#endif //CONFIGURE_H
