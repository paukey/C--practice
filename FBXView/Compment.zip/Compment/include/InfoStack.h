#ifndef INFOSTACK_H
#define INFOSTACK_H
#include "string.h"

typedef char InfoStr[512];
typedef void (*cbfunc)(InfoStr str);
class CInfoStack
{
protected:
	InfoStr *	m_InfoArray;
	int			m_Size;
	int			m_CountInfo;
	int			m_Tail;
	int			m_Head;
	int			m_CurPos;
	cbfunc		m_CBFunc;
public:
	CInfoStack(void);
	~CInfoStack(void);
	void PushInfo(InfoStr str);
	void RegCallFunc(cbfunc func);
};

#endif
