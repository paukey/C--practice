#ifndef __ESK_MATH_TYPES_H
#define __ESK_MATH_TYPES_H

#ifdef __cplusplus
extern "C" {
#endif


union _Matrix2
{
    struct
    {
        float m00, m01;
        float m10, m11;
    };
    float m2[2][2];
    float m[4];
};

typedef union _Matrix2 CMatrix2;

#ifdef __cplusplus
}
#endif

#endif /* _ESK_MATH_TYPES_H */
