//
//  Quaternion.h
//

#ifndef __ESK_QUATERNION_H
#define __ESK_QUATERNION_H

#include <math.h>

#include "EsKitTypes.h"

#include "Vector3.h"
#include "Vector4.h"



class CQuaternion
{
public:
	union
	{
		//struct { CVector3 v; float s; };//�淶�ϸ��C++�����������ۺ�
		struct { float x, y, z, w; };
		float q[4];
	};
	CQuaternion();
	CQuaternion(float x, float y, float z, float w);
	CQuaternion(CVector3 vector, float scalar);
	CQuaternion(float values[4]);
	float Length();
	CQuaternion Normalize();

	CQuaternion operator+(const CQuaternion &quaternionRight);
	CQuaternion operator-(const CQuaternion &quaternionRight);
	CQuaternion operator*(const CQuaternion &quaternionRight);

	void MakeWithAngleAndAxis(float radians, float x, float y, float z);	//�ٶ������Ѿ��淶���������� 
	void MakeWithAngleAndVector3Axis(float radians, CVector3 axisVector);	//�ٶ������Ѿ��淶���������� 


	CVector3 RotateVector3(CVector3 vector);
	CVector4 RotateVector4(CVector4 vector);
	CQuaternion GetInvert();
	CQuaternion GetConjugate();
};






#ifdef __cplusplus
extern "C" {
#endif

#ifdef gggggg   
Quaternion QuaternionMakeWithMatrix3(Matrix3 matrix);
Quaternion QuaternionMakeWithMatrix4(Matrix4 matrix);

/*
 Calculate and return the angle component of the angle and axis form.
 */
float QuaternionAngle(Quaternion quaternion);

/*
 Calculate and return the axis component of the angle and axis form.
 */
Vector3 QuaternionAxis(Quaternion quaternion);
    

	
Quaternion QuaternionSlerp(Quaternion quaternionStart, Quaternion quaternionEnd, float t);



static  Vector3 QuaternionRotateVector3(Quaternion quaternion, Vector3 vector);
void QuaternionRotateVector3Array(Quaternion quaternion, Vector3 *vectors, size_t vectorCount);
    
/*
 The fourth component of the vector is ignored when calculating the rotation.
 */
static  Vector4 QuaternionRotateVector4(Quaternion quaternion, Vector4 vector);
void QuaternionRotateVector4Array(Quaternion quaternion, Vector4 *vectors, size_t vectorCount);
    

#endif
#ifdef __cplusplus
}
#endif

#endif /* __GLK_QUATERNION_H */
