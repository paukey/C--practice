#ifndef CMOUSEEVENT_H
#define CMOUSEEVENT_H

class CMouseEvent
{
public:
	CMouseEvent(void);
	virtual ~CMouseEvent(void);
	virtual void OnLButtonDown(int x, int y, int ID);
	virtual void OnLButtonUp(int x, int y, int ID);
	virtual void OnRButtonDown(int x, int y, int ID);
	virtual void OnRButtonUp(int x, int y, int ID);
	virtual void OnMouseMove(int x, int y, int ID);
	virtual void OnMouseDrag(int x, int y, int ID);

};
#endif
