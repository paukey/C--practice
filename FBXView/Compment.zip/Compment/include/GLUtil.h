#ifndef GLUTIL_H
#define GLUTIL_H

#include "Configure.h"

#include <string.h>
#define MATROW 3
#define MATCOL 6

class CMatrix4;
class CMatStack;
class CEGLUtil
{
protected:
	float tmpmat[MATROW*MATCOL];		//��N���Ǹ���λ����
	CMatStack *m_pStack;
	static int m_CountHinstance;		//����һ�������˶��ٸ�����
	float m_EyeX;
	float m_EyeY;
	float m_EyeZ;
	CMatrix4 *m_Result;
	CEGLUtil(void);
	static CEGLUtil *m_Handel;
	void GetInv(float *_mat);
	void LineAdd(float *_mat, int a, int b, float k = 1.0f); //��b�г�k�ӵ���a��
	void MakeUnit(float *_mat);
	void CreateNorMatrix();						//���ɷ��߾���������ͼģ�;����������ת��
	float m_NormalMat[MATROW][MATROW];					//���߾���
	CMatrix4 *m_ModelViewMat;
	
public:
	static CEGLUtil * GetHandel();
	~CEGLUtil(void);
	static void Free();
	void LoadIdentity(void);
	void PushMatrix(void);
	void PopMatrix(void);
	void Rotate(GLfloat angle, GLfloat x, GLfloat y, GLfloat z);
	void SetPerspective(float fovy, float aspect, float nearZ, float farZ);	
	void Translate(GLfloat tx, GLfloat ty, GLfloat tz);
	void Scale(GLfloat sx, GLfloat sy, GLfloat sz);
	void LookAt(GLfloat eyex, GLfloat eyey, GLfloat eyez, GLfloat centerx, GLfloat centery, GLfloat centerz, GLfloat upx, GLfloat upy, GLfloat upz);
	float * GetMVPMat();
	float * GetModelMat();
	float * GetViewMat();
	float * GetProjMat();
	float * GetNorMat();
	float * GetModelViewMat();
	bool UnProject(float winx, float winy, float winz,  int *viewport, float *wordpos);
};
#endif
