#ifndef MS3DMODEL_H
#define MS3DMODEL_H
#include <stdio.h>
#include<stdlib.h>
#include <string.h>
#include "Configure.h"
//#include "ShaderManager.h"
//#include "ImageBuf.h"
#include "Vector3.h"
#include "Matrix4.h"
#include "Camera.h"
//#include "ShaderManager.h"

typedef char _byte;
typedef short word;
#pragma pack(push)
#pragma pack(1)

struct TMS3DVertex
{
	_byte m_ucFlags;
	float vertex[3];
	char boneId;
	_byte referenceCount;
};
struct TMS3DFace
{
	word m_usFlags;
	word m_usVertIndices[3];
	float m_vNormals[3][3];
	float m_fTexCoordt[2][3];
	//float m_fTexCoords[3];
	_byte m_ucSmoothing;
	_byte m_ucGroup;
};
struct TMS3DGroupPart
{
	 _byte m_ucFlags;
	 char m_cName[32];
	 word m_usNumTris;
};
struct TMS3DMaterial
{
    char m_cName[32];
    float m_fAmbient[4];
    float m_fDiffuse[4];
    float m_fSpecular[4];
    float m_fEmissive[4];
    float m_fShininess;
    float m_fTransparency;
    _byte m_cMode;
    char m_cTexture[128];
    char m_cAlphaFile[128];
};
struct TMS3DKeyFrame
{
	float m_fTime;
	float m_fParams[3];
};
struct TMS3DJoint
{
	 _byte m_ucpFlags;
	 char m_cName[32];
	 char m_cParent[32];
	 float m_fRotation[3];
	 float m_fPosition[3];
	 word m_usNumRotFrames;
	 word m_usNumTransFrames;
	 TMS3DKeyFrame *m_RotKeyFrames;
	 TMS3DKeyFrame *m_TransKeyFrames;
};
struct TMS3DHeader 
{
	char Indentifier[10];
	int Version;
};
#pragma pack(pop)
#pragma pack(push)
#pragma pack(4)

//===========================================================================
struct CustomVer
{
	float x,y,z;
	float u,v;
	float r,g,b,a;
};
struct AniVertex		//ms3d_vertex_t  TVertex
{
	float x,y,z;
	char BoneID;
};

struct AniTexCoord	//TTexCoord	
{
	float u,v;
};

struct AniTriangle				//ms3d_triangle_t
{
	word VertexIndices[3];
	float   Normals[3][3]; //Normals:array[1..3] of TVertex3;
	AniTexCoord TexCoords[3];
	word GroupId;
};
       
struct Anigroup						//ms3d_group_t
{
	char Name[32];
	word FaceCount;
	word *FaceIndices;				//��ǰ���ڣ�ÿ���������
	word MaterialID;
};

			

struct AniMaterial				//ms3d_material_t
{
	float           Ambient[4];                         //
	float           Diffuse[4];                         //
	float           Specular[4];                        //
	float           Emissive[4];                        //Ambient,Diffuse,Specular,Emissive:array[1..4] of single;		
	_byte Shininess;
	float Transparency;
	GLuint TextureID;
	float MaxU;
	float MaxV;
};
struct AniKeyFrame			//ms3d_keyframe_rot_t
{
	float Time;
	float X,Y,Z;
};
struct AniJoint							//ms3d_joint_t
{
	char Name[32];
	char ParentName[32];
	AniKeyFrame OriRotate;
	AniKeyFrame OriPosition;
	int RotFrameCount;
	int TransFrameCount;
	AniKeyFrame *RotFrames;
	AniKeyFrame *TransFrames;
	short ParentID;
	CMatrix4 MatLocal;
	CMatrix4 MatAbs;
	CMatrix4 MatFinal;
	AniKeyFrame CurRotFrame;
	AniKeyFrame CurTransFrame;
};

struct  AnimInfo
{
	char AnimName[32];
	int StartFrame;
	int EndFrame;
	bool Loop;
	float Speed;
};

class TMesh
{
public:
	TMesh();
	AniVertex *Vertices;
	AniTriangle *Faces;
	AniMaterial *Materials;
	Anigroup *Groups;
	int VertexCount;
	int FaceCount;
	int MaterialCount;
	int GroupCount;

	void Free();
	void EnableMaterial(int ID);
};

struct RenderData
{
	CVector3		*m_Vertex;
	CVector3		*m_Normal;
	float			*m_Color;
	GLuint			m_CurVerObj;					//�Զ����ʽ�Ķ��㻺�����
	GLuint			m_VertexObj;
	GLuint			m_NormalObj;
	GLuint			m_TexObj;
	GLuint			m_3DTexID;
	GLuint			m_ColorObj;
	AniTexCoord		*m_TexData;
	int				m_CountPoint;
	float           Ambient[4];                         //
	float           Diffuse[4];                         //
	float           Specular[4];                        //
	float           Emissive[4];                        //Ambient,Diffuse,Specular,Emissive:array[1..4] of single;		
	_byte			Shininess;
	float			Transparency;
	GLuint			TextureID;
};



//===========================================================================

class CMs3dModel
{
protected:
	GLuint uiProgram, uiFragShader, uiVertShader;
	unsigned char *	m_DataBuf;
	int				m_ReadPos;
	int				m_Length;
	void SetAniFaces();
	void SetAniGroups();
	void SetAniMaterials();
	void SetAniVertex();
	GLuint LoadTexturesFromFile(char *FileName);
	void LoadAnimData();
	void GetWord(char *s,int id, char *Result);
	void LoadAnimListFromStringList(char **s1,int countani);
	void LoadAnimListFromFile(char *FileName);
	char AniFile[255];

	//====================================
	//ԭANIMODEL��Ա
	CMatrix4		**m_JointMat;			//Ӧ�����ж��ٸ�BOINID�����ж��ٸ�������ָ��ָ��ÿ������,�������������øĶ���ĳ���
	RenderData		*m_RenderData;
	int				m_CountData;		//�ж��ٸ����������ж��ٸ�����
	int				m_CountMat;
	//CShaderManager  m_ShaderMan;			//Shader������
	void TransformVecs();
	void TransformNormals();
	float CurTime;
	//====================================
	//ԭANIMATION��Ա
	void CreateMatrices();
	char *Name[32];
	AniJoint *Joints;
	int JointCount;
	float FPS;
	int TotalFrames;
	void Free();
	void FindParents();
	
	float m_ScaleX;
	float m_ScaleY;
	float m_ScaleZ;
	//====================================
	static int m_CountObj;				//��������ʵ��������
	static GLuint m_Ms3dProg;
	GLuint	m_VertShader;
	GLuint	m_FragShader;
	static GLuint	m_iLocPosition;
	static GLuint	m_iTex;
	static GLuint	m_iSimp;
	static GLuint	m_iLocColour;
	static GLuint	m_MatLoc[48];
	static GLuint	m_iLocMVP;
	CCamera		*m_Camera;
	CVector3	m_Pos;
	float		m_FrameUpdateSpeed;	//֡�л��ٶ�
public:
	//====================================
	void InitShader();		//��ʼ��SHADER
	void DelShader();		//�����һ�������ͷŵ�ʱ�򣬵��øú���
	//ԭANIMODEL��Ա
	bool AniList;			//�Ƿ���ANI�ļ�
	int AnimationID;		//��ǰ���ŵĶ�����ID
	TMesh MeshData;
	//CAnimation AnimationData;
	int AnimationCount;
	bool DrawBone;
	AnimInfo *AnimInfoList;
	//====================================
	//CAniModel ModelData;
	CMs3dModel(void);
	~CMs3dModel(void);
	void LoadFromFile(char * file);
	void ReadBuf(void * buf, int size);
	void LoadFromBuf(void);
	void Render(CCamera		*mcam);
	//======================================
	void InitAniModel(void);
	void DeAniModel(void);

	void Initialize(bool TransformVec = true);
	void SetBaseData();
	void NewRender();
	void SetPos(CVector3 pos);
	void SetPlaySpeed(float speed);
	//void RenderModel();
	//void RenderSkeleton();
	void SetAnimation(int id);

	void AddAnimInfo(char *AnimName,int  StartFrame, int EndFrame, float Speed, bool Loop);
	void AdvanceFrame(float dTime);
	void SetScale(float x, float y, float z);
	
};

#pragma pack(pop)
#endif
