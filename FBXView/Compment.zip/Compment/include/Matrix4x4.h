#ifndef MATRIX4x4_H
#define MATRIX4x4_H

#include "Vector3.h"
#include <string.h>


#ifndef vec4
	typedef unsigned short word;
	typedef unsigned char byte;
	typedef float vec4[4];
	typedef float mat4[16];
#endif


class CMatrix4x4
{
protected:
	static float det(float * m, int a1, int a2, int a3, int a4, int a5, int a6, int a7, int a8, int a9);
public:
	CMatrix4x4(void);
	CMatrix4x4(const CMatrix4x4 &tmp);
	void SetRotation(const CVector3 & vec);
	~CMatrix4x4(void);
	
	void SetIdentity();								//����һ����λ����
	CMatrix4x4 operator*(const CMatrix4x4 &mat);		//�������
	CVector3 Multiply(const CVector3 &vec);			//��һ���������˷�
	CVector3 MultiplySSE(const CVector3 &vec);		//ʹ��SSEָ�����˷�
	CMatrix4x4  &operator = (const CMatrix4x4 &v);		//�Ⱥ�����
	bool	operator==(const CMatrix4x4 &v);			//��Ⱥ�����

	float M[16];
	
	void RotateVec(CVector3 & vec);				//��ת����		
	void TranslateVec(CVector3 & Vec);			//ƽ�ƾ���
	void InverseTranslateVec(CVector3 & vec);
	void InverseRotateVec(CVector3 &vec);
	void SetInverseTranslate(float x, float y, float z);
	void SetInverseRotate(float x, float y, float z);
	void SetTranlate(float x, float y, float z);
	void PostMultiply(CMatrix4x4 Matrix);
	//DELPHI
	void Translate(float x, float y, float z);	//ƽ�ƾ����棿��
	CMatrix4x4 MakeRotXYZ(const CVector3 & vec);	//
	CVector3 Transform(const CVector3 & v);		//
	CMatrix4x4 Transpose(void);					//ת��
	CMatrix4x4 Inverse(void);						//�������
	void Zero(void);							//��0
	void RotateX(float theta);
	void RotateY(float theta);
	void RotateZ(float theta);
	void Init(float m00, float m01, float m02, float m03,
			 float m10, float m11, float m12, float m13,
			 float m20, float m21, float m22, float m23,
			 float m30, float m31, float m32, float m33);
};

#endif